﻿using OpenQA.Selenium;
using SeleniumExtras.PageObjects;

namespace Sanofi___Selenium.pages
{
	public class LoginModal
	{
		public By Entrar = By.Id("btnLogin");

		public By PorEmail = By.Id("sf-is-not-hcp");

		public By ProfileMeBotaoLogarnu = By.Id("sf-continue-validation");

		public By CampoEmail = By.Id("lf-email");

		public By CampoSenha = By.Id("sf-password");

		public By UF = By.Id("uf");

		public By NumRegistro = By.Id("lf-registro");

		public By EsqueciSenha = By.Id("forgot-pass");

		public By Prosseguir = By.Id("sf-email-different");

		public By Reenviar = By.Id("lf-resend-mail");

		public By EmailSemAcesso = By.XPath("//div[@id='modal-login']//div[@class='c-text c-text--link']");

		public By TipoHCP = By.Id("hcp-type");

		public By Telefone = By.Id("Telefone");

		public By CriarConta = By.Id("btnSignUp");

		public By Termos = By.Id("opt-in");

		public By Nome = By.Id("sf-name");

		public By Sobrenome = By.Id("sf-lastname");

		public By CampoCelular = By.Id("sf-cellphone");

		public By Senha = By.Id("sf-password");

		public By RepetirSenha = By.Id("sf-password-confirm");

		public By ConfirmcaoEmail = By.Id("sf-diff-email");

		public By NumeroRegistro = By.Id("sf-register-2");

		public By EmailCriar = By.Id("sf-email");

		public By ProfileLog = By.XPath("//div[@class='menu-profile menu-profile--logged']");

		public By EncerrarSessao = By.XPath("//a[@class='c-text menu-profile__panel-item menu-profile__panel-item--link menu-profile__panel-item--danger menu-profile__panel-item--text-left']");

		public By ProSim = By.Id("sf-is-hcp");

		public By BotaoLogar = By.Id("sf-continue-validation");

		public By ConfirmaTelefone = By.Id("sf-phone"); 

		public By CadastroDepois = By.Id("sf-create-account-after");
		//[FindsBy(How = How.Id, Using = "sf-diff-email")]
		//public IWebElement ConfirmcaoEmail { get; set; }

		//[FindsBy(How = How.Id, Using = "sf-register-2")]
		//public IWebElement NumeroRegistro { get; set; }

		//[FindsBy(How = How.Id, Using = "sf-email")]
		//public IWebElement EmailCriar { get; set; }

		//[FindsBy(How = How.XPath, Using = "//div[@class='menu-profile menu-profile--logged']")]
		//public IWebElement ProfileLog { get; set; }

		//[FindsBy(How = How.XPath, Using = "//a[@class='c-text menu-profile__panel-item menu-profile__panel-item--link menu-profile__panel-item--danger menu-profile__panel-item--text-left']")]
		//public IWebElement EncerrarSessao { get; set; }

		//[FindsBy(How = How.Id, Using = "sf-is-hcp")]
		//public IWebElement ProSim { get; set; }






		//[FindsBy(How = How.Id, Using = "btnLogin")]
		//public IWebElement Entrar { get; set; }

		//[FindsBy(How = How.Id, Using = "sf-is-not-hcp")]
		//public IWebElement PorEmail { get; set; }

		//[FindsBy(How = How.Id, Using = "sf-continue-validation")]
		//public IWebElement BotaoLogar { get; set; }

		//[FindsBy(How = How.Id, Using = "lf-email")]
		//public IWebElement CampoEmail { get; set; }

		//[FindsBy(How = How.Id, Using = "sf-password")]
		//public IWebElement CampoSenha { get; set; }

		//[FindsBy(How = How.Id, Using = "uf")]
		//public IWebElement UF { get; set; }

		//[FindsBy(How = How.Id, Using = "lf-registro")]
		//public IWebElement NumRegistro { get; set; }

		//[FindsBy(How = How.Id, Using = "forgot-pass")]
		//public IWebElement EsqueciSenha { get; set; }

		//[FindsBy(How = How.Id, Using = "sf-email-different")]
		//public IWebElement Prosseguir { get; set; }

		//[FindsBy(How = How.Id, Using = "lf-resend-mail")]
		//public IWebElement Reenviar { get; set; }

		//[FindsBy(How = How.XPath, Using = "//div[@id='modal-login']//div[@class='c-text c-text--link']")]
		//public IWebElement EmailSemAcesso { get; set; }

		//[FindsBy(How = How.Id, Using = "hcp-type")]
		//public IWebElement TipoHCP { get; set; }

		//[FindsBy(How = How.Id, Using = "sf-phone")]
		//public IWebElement Telefone { get; set; }

		//[FindsBy(How = How.Id, Using = "btnSignUp")]
		//public IWebElement CriarConta { get; set; }

		//[FindsBy(How = How.Id, Using = "opt-in")]
		//public IWebElement Termos { get; set; }

		//[FindsBy(How = How.Id, Using = "sf-name")]
		//public IWebElement Nome { get; set; }

		//[FindsBy(How = How.Id, Using = "sf-lastname")]
		//public IWebElement Sobrenome { get; set; }

		//[FindsBy(How = How.Id, Using = "sf-cellphone")]
		//public IWebElement CampoCelular { get; set; }

		//[FindsBy(How = How.Id, Using = "sf-password")]
		//public IWebElement Senha { get; set; }

		//[FindsBy(How = How.Id, Using = "sf-password-confirm")]
		//public IWebElement RepetirSenha { get; set; }


	}
}
