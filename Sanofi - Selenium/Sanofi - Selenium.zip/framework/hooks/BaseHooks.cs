﻿using AventStack.ExtentReports;
using AventStack.ExtentReports.Gherkin.Model;
using AventStack.ExtentReports.Reporter;
using Sanofi___Selenium.framework.core;
using Sanofi___Selenium.framework.steps;
using TechTalk.SpecFlow;

namespace Sanofi___Selenium.core.hooks
{
	[Binding]
	public sealed class BaseHooks : BaseSteps
	{
		private static ExtentReports Extent;
		private static ExtentTest Scenario;
		private static ExtentTest FeatureName;
		private static Report report;
		[BeforeTestRun]
		public static void BeforeTestRun()
		{
			var HtmlReporter = new ExtentHtmlReporter(@"D:\automação\sanofi\Sanofi\TestResults\Report.txt");
			HtmlReporter.Config.Theme = AventStack.ExtentReports.Reporter.Configuration.Theme.Dark;
			Extent = new ExtentReports();
			Extent.AttachReporter(HtmlReporter);

			report = new Report(@"D:\automação\sanofi\Sanofi\TestResults\Report.html");
		}


		[BeforeFeature]
		public static void BeforeFeature(FeatureContext context)
		{
			string titulo = context.FeatureInfo.Title;
			FeatureName = Extent.CreateTest<Feature>(context.FeatureInfo.Title);
			report.Escrever(context.FeatureInfo.Title);
		}


		[AfterScenario]
		public void AfterScenario()
		{
			App.Dispose();
		}

		[BeforeScenario]
		public static void BeforeScenario(ScenarioContext context)
		{
			App.Initalize();
			Scenario = Extent.CreateTest<Scenario>(context.ScenarioInfo.Title);
			report.Escrever(context.ScenarioInfo.Title);
		}

		[AfterStep]
		public void InsertingReportingSteps(ScenarioContext context)
		{
			string StepType;
			StepType = ScenarioStepContext.Current.StepInfo.StepDefinitionType.ToString();

			if (context.TestError == null)
			{
				report.Escrever(ScenarioStepContext.Current.StepInfo.Text);
				if (StepType == "Given")
					Scenario.CreateNode<Given>(ScenarioStepContext.Current.StepInfo.Text);
				else if (StepType == "When")
					Scenario.CreateNode<When>(ScenarioStepContext.Current.StepInfo.Text);
				else if (StepType == "Then")
					Scenario.CreateNode<Then>(ScenarioStepContext.Current.StepInfo.Text);
			}
			else if (context.TestError != null)
			{
				report.Escrever(ScenarioStepContext.Current.StepInfo.Text + context.TestError.Message);
				if (StepType == "Given")
					Scenario.CreateNode<Given>(ScenarioStepContext.Current.StepInfo.Text + context.TestError.Message).Fail(context.TestError.Message);
				else if (StepType == "When")
					Scenario.CreateNode<When>(ScenarioStepContext.Current.StepInfo.Text + context.TestError.Message).Fail(context.TestError.Message);
				else if (StepType == "Then")
					Scenario.CreateNode<Then>(ScenarioStepContext.Current.StepInfo.Text + context.TestError.Message).Fail(context.TestError.Message);
			}
		}

		[AfterTestRun]
		public static void AfterTestRun()
		{
			Extent.Flush();
			report.GerarArquivo();
		}
	}
}
