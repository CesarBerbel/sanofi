﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using Sanofi___Selenium.framework.core;
using Sanofi___Selenium.framework.Pages;
using Sanofi___Selenium.framework.steps;
using System;
using System.Configuration;
using TechTalk.SpecFlow;

namespace Sanofi___Selenium.steps
{
    [Binding]
    public class ArtigoSteps : BaseSteps
    {
        [When(@"eu clico no artigo ""(.*)""")]
        public void QuandoEuClicoNoArtigo(string artigo)
        {
			App.GetTextBy(By.XPath("//h2[contains(text(),'" + artigo + "')]/ancestor::a"));
			BrowserFactory.Driver.FindElement(By.XPath("//h2[contains(text(),'" + artigo + "')]/ancestor::a")).Click();
		}

		[When(@"eu clico em SIM")]
        public void QuandoEuClicoEmSIM()
        {
			App.Select(BasePage.LoginModal.ProSim);
		}

		[When(@"eu clico em Prosseguir")]
        public void QuandoEuClicoEmProsseguir()
        {
			App.Click(BasePage.LoginModal.BotaoLogar);
        }

		[When(@"clico em Finalizar Validacao")]
		public void QuandoClicoEmFinalizarValidacao()
		{
			App.Click(BasePage.LoginModal.BotaoLogar);
		}

		[Then(@"devo ver a mensagem ""(.*)""")]
		public void EntaoDevoVerAMensagem(string msg)
		{
			string mensagem = App.GetTextBy(By.XPath("//div[@id='modal-soft-login']//h2"));
			Asserts.VerificarString(msg, mensagem);
		}

		[Then(@"eu devo ser direcionado para página de validacao")]
		public void EntaoEuDevoSerDirecionadoParaPaginaDeValidacao()
		{			
			string mensagem = App.WaitText("//div[@id='modal-soft-login']//div[@class='c-text c-text--h2']", "Validação");
			Asserts.VerificarString("Validação", mensagem);
		}

		[Then(@"devo ver a mensagem de sucesso ""(.*)""")]
		public void EntaoDevoVerAMensagemDeSucesso(string msg)
		{			
			string mensagem = App.WaitText("//div[@class='c-text c-text--h3 c-modal-sf-hcp__title']/strong", msg);
			Asserts.VerificarString(msg, mensagem);
		}

		[Then(@"eu visualizo o artigo ""(.*)""")]
		public void EntaoEuVisualizoOArtigo(string url)
		{
			Asserts.VerificarUrl(url);
		}

		[Then(@"devo ver as mensagens de erro de acesso Oops!,Olá Dentista,,Esse conteúdo é exclusivo para ""(.*)""")]
		public void EntaoDevoVerAsMensagensDeErroDeAcessoOopsOlaDentistaEsseConteudoEExclusivoPara(string especialidades)
		{
			string mensagem = App.GetTextBy(By.XPath("//div[@class='c-text c-text--text-left c-text--wraped']/p/span[2]"));
			Asserts.VerificarString(mensagem, especialidades);
		}

		[When(@"clico em Deixar para depois")]
		public void QuandoClicoEmDeixarParaDepois()
		{
			App.Click(BasePage.LoginModal.CadastroDepois);
		}

		[Given(@"que eu retorne para home")]
		public void DadoQueEuRetorneParaHome()
		{
			App.GoTo(ConfigurationManager.AppSettings["URL"]);
		}

	}
}